
import hero from './hero'
import post from './post'
import feature from './feature'

export const schemaTypes = [hero, post, feature]
